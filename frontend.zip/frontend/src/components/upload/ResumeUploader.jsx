import { motion } from "framer-motion";
import { FiUploadCloud } from "react-icons/fi";

const ResumeUploader = ({ onUpload }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      className="border-2 border-dashed border-gray-600 rounded-xl p-10 text-center bg-black"
    >
      <FiUploadCloud className="text-5xl mx-auto mb-4 text-gray-300" />

      <h3 className="text-xl font-semibold mb-2">
        Upload your resume
      </h3>

      <p className="text-gray-400 mb-6">
        PDF or DOCX • Drag & drop or click to upload
      </p>

      <input
        type="file"
        accept=".pdf,.doc,.docx"
        className="hidden"
        id="resume-upload"
        onChange={(e) => onUpload(e.target.files[0])}

      />

      <label
        htmlFor="resume-upload"
        className="inline-block bg-white text-black px-6 py-3 rounded cursor-pointer hover:bg-gray-200 transition"
      >
        Choose Resume
      </label>
    </motion.div>
  );
};

export default ResumeUploader;
