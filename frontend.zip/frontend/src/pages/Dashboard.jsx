// import { useState } from "react";
// import ResumeUploader from "../components/upload/ResumeUploader";
// import Processing from "../components/upload/Processing";
// import SkillsPanel from "../components/dashboards/SkillsPanel";
// import JobCard from "../components/JobCard";
// import Reveal from "../components/Reveal";

// const Dashboard = () => {
//   const [loading, setLoading] = useState(false);
//   const [skills, setSkills] = useState([]);
//   const [jobs, setJobs] = useState([]);

//   // ✅ SINGLE correct handleUpload
//   const handleUpload = async (file) => {
//   if (!file) return;

//   setLoading(true);

//   try {
//     // 1️⃣ Upload resume → get skills
//     const formData = new FormData();
//     formData.append("resume", file);

//     const res = await fetch("http://localhost:5000/api/resume/upload", {
//       method: "POST",
//       body: formData,
//     });

//     if (!res.ok) throw new Error("Resume upload failed");

//     const resumeData = await res.json();
//     const extractedSkills = resumeData.skills || [];

//     setSkills(extractedSkills);

//     // 2️⃣ Fetch live job recommendations USING skills
//     const jobsRes = await fetch(
//       "http://localhost:5000/api/recommendations/live",
//       {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           resumeSkills: extractedSkills,
//         }),
//       }
//     );
  


//     if (!jobsRes.ok) throw new Error("Job fetch failed");

//     const jobsData = await jobsRes.json();
//     console.log("🔥 JOBS API RESPONSE:", jobsData)
//     console.log("🔥 SETTING JOBS:", jobsData.recommendations);


//     setJobs(jobsData.recommendations || []);
//   } catch (error) {
//     console.error(error);
//     alert("Something went wrong while analyzing your resume");
//   } finally {
//     setLoading(false);
//   }
// };


//   return (
//     <div className="max-w-7xl mx-auto px-6 py-10 text-white">
//       <Reveal>
//         <ResumeUploader onUpload={handleUpload} />
//       </Reveal>

//       {loading && <Processing />}

//       {skills.length > 0 && (
//         <Reveal delay={0.2}>
//           <SkillsPanel skills={skills} />
//         </Reveal>
//       )}

//       {jobs.length > 0 && (
//         <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
//           {jobs.map((job, i) => (
//             <Reveal delay={i * 0.1} key={i}>
//               <JobCard job={job} />
//             </Reveal>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default Dashboard;

import { useState } from "react";
import ResumeUploader from "../components/upload/ResumeUploader";
import Processing from "../components/upload/Processing";
import SkillsPanel from "../components/dashboards/SkillsPanel";
import JobCard from "../components/JobCard";
import Reveal from "../components/Reveal";

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [skills, setSkills] = useState([]);
  const [jobs, setJobs] = useState([]);

  const handleUpload = async (file) => {
    if (!file) return;

    setLoading(true);

    try {
      // 1️⃣ Upload resume → extract skills
      const formData = new FormData();
      formData.append("resume", file);

      const res = await fetch("http://localhost:5000/api/resume/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Resume upload failed");

      const resumeData = await res.json();
      const extractedSkills = resumeData.skills || [];

      setSkills(extractedSkills);

      // 2️⃣ Fetch live job recommendations
      const jobsRes = await fetch(
        "http://localhost:5000/api/recommendations/live",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            resumeSkills: extractedSkills,
            location: India,
          }),
        }
      );

      if (!jobsRes.ok) throw new Error("Job fetch failed");

      const jobsData = await jobsRes.json();
      console.log("🔥 JOBS API RESPONSE:", jobsData);

      setJobs(jobsData.recommendations || []);
    } catch (error) {
      console.error(error);
      alert("Something went wrong while analyzing your resume");
    } finally {
      setLoading(false);
    }
  };
  console.log("🟢 JOBS STATE:", jobs);
  return (
    <div className="max-w-7xl mx-auto px-6 py-10 text-white">
      {/* Upload Section */}
      <Reveal>
        <ResumeUploader onUpload={handleUpload} />
      </Reveal>

      {loading && <Processing />}

      {/* Skills */}
      {skills.length > 0 && (
        <Reveal delay={0.2}>
          <SkillsPanel skills={skills} />
        </Reveal>
      )}

      {/* ✅ Job Cards — NO Reveal HERE */}
      {jobs.length > 0 && (
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          {jobs.map((job, i) => (
            <JobCard key={i} job={job} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
